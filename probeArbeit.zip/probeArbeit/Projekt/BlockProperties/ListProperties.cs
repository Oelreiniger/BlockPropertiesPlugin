﻿using Autodesk.AutoCAD.ApplicationServices.Core;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;
using BlockProperties;
using System;
using System.Collections.Generic;

namespace ListProperties
{
    public class ListProperties
    {
        [CommandMethod("ListProperties")]

        // holt die properties von ausgewählten blöcken raus
        public void ListAttributes()

        {
            Editor ed = Application.DocumentManager.MdiActiveDocument.Editor;
            Database db = HostApplicationServices.WorkingDatabase;

            List<String> attNameList = new List<String>();
            List<String> attValList = new List<String>();

            // transaktionsstart
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {

                // Build a filter list so that only

                // block references are selected

                TypedValue[] filList = new TypedValue[1] { new TypedValue((int)DxfCode.Start, "INSERT") };

                SelectionFilter filter = new SelectionFilter(filList);

                PromptSelectionOptions opts = new PromptSelectionOptions();

                opts.MessageForAdding = "Wählen Sie ein Block aus: ";

                PromptSelectionResult res = ed.GetSelection(opts, filter);


                // Do nothing if selection is unsuccessful

                if (res.Status != PromptStatus.OK)
                    return;


                SelectionSet selSet = res.Value;

                ObjectId[] idArray = selSet.GetObjectIds();

                foreach (ObjectId blkId in idArray)
                {

                    BlockReference blkRef = (BlockReference)tr.GetObject(blkId, OpenMode.ForRead);

                    BlockTableRecord btr = (BlockTableRecord)tr.GetObject(blkRef.BlockTableRecord, OpenMode.ForRead);

                    ed.WriteMessage("\nBlock: " + btr.Name);

                    btr.Dispose();

                    Autodesk.AutoCAD.DatabaseServices.AttributeCollection attCol = blkRef.AttributeCollection;

                    foreach (ObjectId attId in attCol)

                    {

                        AttributeReference attRef = (AttributeReference)tr.GetObject(attId, OpenMode.ForRead);


                        attNameList.Add(attRef.Tag);
                        attValList.Add(attRef.TextString);

                        string str =

                          ("\n  Attribut Name: "

                            + attRef.Tag

                            + "\n    Attribut Wert: "

                            + attRef.TextString
                        );
                        ed.WriteMessage(str);
                    }
                }
                tr.Commit();
            }

            // Startet das Fenster wo die properties displayed werden sollen
            Fenster f = new Fenster(attNameList.ToArray(), attValList.ToArray());
            f.Show();
        }
    }
}
