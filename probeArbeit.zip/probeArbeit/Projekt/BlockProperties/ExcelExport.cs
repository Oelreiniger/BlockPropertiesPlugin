﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using MiniExcelLibs;

namespace BlockProperties
{
    public class ExcelExport
    {
        public ExcelExport()
        {
        }

        //erstellung einer datei im excel format
        public void createFile(string newFilepath, String[] newTagList, String[] newTextList)
        {
            var values = new List<Dictionary<string, object>>();

            for (int i = 0; i < newTagList.Length; i++)
            {
                values.Add(new Dictionary<string, object> { { "tags", newTagList[i] }, { "text", newTextList[i] } });

            }
            MiniExcel.SaveAs(newFilepath, values);

        }

    }
}
