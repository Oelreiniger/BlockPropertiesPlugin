﻿using Autodesk.AutoCAD.GraphicsInterface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlockProperties
{
    public partial class Fenster : Form
    {
        private String[] tagList;
        private String[] textList;

        private Label[] tagLabels;
        private Label[] textLabels;

        public Fenster(String[] newTagList, String[] newTextList){

            tagList = newTagList;
            textList = newTextList;

            InitializeComponent();
            this.Size = new Size(420, 650);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;


            Button exportButton = new Button();
            exportButton.Text = "Export";
            exportButton.Click += new EventHandler(exportButton_Click);
            exportButton.Left = 55;
            exportButton.Top = 545;
            this.Controls.Add(exportButton);


            displaytext();
        }

        //clickEvent von dem export button
        private void exportButton_Click(object sender, System.EventArgs e)
        {
            String path = selectPath();

            //wenn der pfad leer ist soll nix passieren
            if (path != "")
            {
                ExcelExport excel = new ExcelExport();
                excel.createFile(path, tagList, textList);
            }

        }

        //dialog zum auswaehelen des speicherorts und namen
        private String selectPath()
        {
            String path = "";

            SaveFileDialog sfd = new SaveFileDialog();

            sfd.InitialDirectory = "c:\\";
            sfd.RestoreDirectory = true;
            sfd.FileName = "objectProperties.xlsx";
            sfd.DefaultExt = "xlsx";
            sfd.Filter = "Excel (*.xlsx) | *.xlsx";

            if (sfd.ShowDialog() == DialogResult.OK)
            {

                path = Path.GetFullPath(sfd.FileName);

                //loescht die datei fall sie schon existiert
                if (File.Exists(path) == true)
                {
                    File.Delete(sfd.FileName);
                }
            }

            return path;
        }

        private void displaytext()
        {
            tagLabels = new Label[tagList.Length];
            textLabels = new Label[textList.Length];

            Label propHeadline = new Label();
            propHeadline.Text = "Properties";
            propHeadline.Left = 50;
            propHeadline.Top = 5;
            propHeadline.AutoSize = true;

            this.Controls.Add(propHeadline);

            //panel im hintergrund fuer umrandung von propPanel2
            Panel propPanel1 = new Panel();
            propPanel1.BackColor = Color.Black;
            propPanel1.Left = 50;
            propPanel1.Top = 30;
            propPanel1.Size = new Size(308, 504);
            this.Controls.Add(propPanel1);


            Panel propPanel2 = new Panel();
            propPanel2.Size = new Size(304, 500);
            propPanel2.Left = 2;
            propPanel2.Top = 2;
            propPanel2.AutoScroll = true;
            propPanel2.BackColor = Color.DimGray;
            propPanel2.ForeColor = Color.White;

            propPanel1.Controls.Add(propPanel2);

            //start position
            tagLabels[0] = new Label();
            tagLabels[0].Top = 20;
            tagLabels[0].Left = 4;
            tagLabels[0].AutoSize = true;
            tagLabels[0].Text = tagList[0] + ":";
            tagLabels[0].Font = new Font("Calibri", 13, FontStyle.Bold);

            textLabels[0] = new Label();
            textLabels[0].Top = 50;
            textLabels[0].Left = 15;
            textLabels[0].AutoSize = true;
            textLabels[0].Text = textList[0];
            textLabels[0].Font = new Font("Calibri", 12, FontStyle.Italic);


            propPanel2.Controls.Add(tagLabels[0]);
            propPanel2.Controls.Add(textLabels[0]);

            //alle anderen positionen der labels
            if (tagList.Length > 1)
            {
                for (int i = 1; i < tagList.Length; i++)
                {
                    tagLabels[i] = new Label();
                    tagLabels[i].Top = tagLabels[i - 1].Top + 70;
                    tagLabels[i].Left = 4;
                    tagLabels[i].AutoSize = true;
                    tagLabels[i].Text = tagList[i] + ":";
                    tagLabels[i].Font = new Font("Calibri", 13, FontStyle.Bold);

                    propPanel2.Controls.Add(tagLabels[i]);

                    textLabels[i] = new Label();
                    textLabels[i].Top = textLabels[i - 1].Top + 70;
                    textLabels[i].Left = 15;
                    textLabels[i].AutoSize = true;
                    textLabels[i].Text = textList[i];
                    textLabels[i].Font = new Font("Calibri", 12, FontStyle.Italic);

                    propPanel2.Controls.Add(textLabels[i]);
                }
            }

        }
    }
}
